from django.apps import AppConfig


class CharitiesConfig(AppConfig):
    name = 'charities'
